clear
format compact

arm_nonlinear_pi_d_design_Interpreted_MATLAB_Function

T = zeros(1,1000);
for k = 1:1000
    tic
    sim('arm_nonlinear_sim_pi_d_cont_Interpreted_MATLAB_Function')
    T(k) = toc;
end

T_ave = mean(T)