close all
clear
format compact

disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' ����Ώ� P(s)')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')

l = 2.04e-01;
M = 3.90e-01;
J = 7.12e-02;
c = 6.95e-01;
g = 9.81e+00;

% --------------------
a0 = M*g*l/J;
a1 = c/J;
b0 = 1/J;

% --------------------
s = tf('s');

sysP = b0/(s^2 + a1*s + a0)

disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' �K�̓��f�� M(s)')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')

wm     = 6;
alpha1 = 1.4;

sysM2 = wm^2/(s^2 + alpha1*wm*s + wm^2)

disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' �R���g���[���̃Q�C��')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')

kI = (a0*wm)/(alpha1*b0)
kP = wm^2/b0
kD = (alpha1^2*wm^2 - a1*alpha1*wm + a0)/(alpha1*b0*wm)

sysC1 = kP + kI/s + kD*s;
sysC2 = kP + kI/s;

disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' �ڕW�l r(s) ���琧��o�� y(s) �ւ̓`�B�֐� Gyr(s)')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++++')

sysGyr = minreal(sysP*sysC2/(1 + sysP*sysC1))

num = 0;
for rc_deg = [30 60 120 240]   % �ڕW�l (deg)
    num = num + 1;

    % --------------------    
    rc = deg2rad(rc_deg);  % �ڕW�l (rad)
    dc = 0;                % �O��
    
    sim('arm_linear_sim_pi_d_cont')     % ���`�V�~�����[�V����
    y_linear = y;
    
    sim('arm_nonlinear_sim_pi_d_cont_Interpreted_MATLAB_Function')  % ����`�V�~�����[�V����
    
    % --------------------
    figure(num)
    subplot('Position',[0.15 0.15 0.775 0.775])
    
    plot(t,rad2deg(y_linear),'LineWidth',1.5)
    hold on
    plot(t,rad2deg(y),'LineWidth',1.5)
    hold off
    
    set(gca,'FontName','Arial','FontSize',14)
    
    xlabel('$t$ [s]','Interpreter','latex','FontSize',16)
    ylabel('$y(t)$ [deg]','Interpreter','latex','FontSize',16)
    
    legend({'Linear Simulation',...
            'Nonlinear Simulation'},...,
            'Interpreter','latex','FontSize',16,...
            'Location','SouthEast')
    
    ylim([0 rc_deg*6/4])
    set(gca,'YTick',0:rc_deg/4:rc_deg*6/4)
    
    grid on
end

figure(1); movegui('northwest')
figure(2); movegui('northeast')
figure(3); movegui('southwest')
figure(4); movegui('southeast')

